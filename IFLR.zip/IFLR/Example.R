slos.compute.weights <- function(basis)
{
  L <- basis$nbasis
  rng <- getbasisrange(basis)
  breaks <- c(rng[1],basis$params,rng[2])
  M <- length(breaks) - 1
  norder <- L-M+1
  W <- array(0,dim=c(norder,norder,M))
  for (j in 1:M)
  {
    temp <- inprod(basis,basis,rng=c(breaks[j],breaks[j+1]))
    W[,,j] <- temp[j:(j+norder-1),j:(j+norder-1)]
  }
  W
}
######
slos.vec.norm <- function(v)
{
  sqrt(sum(v^2))
}
slos.preprocess.x <- function(X,D)
{
  if(is.matrix(X) || is.fd(X))
  {
    Xtmp <- list()
    Xtmp[[1]] <- X
    X <- Xtmp
    K <- 1
  }
  else K <- length(X)
  
  xfd <- list()
  for(k in 1:K)
  {
    x <- X[[k]]
    if(!is.fd(x))
    {
      if(is.matrix(D)||is.vector(D))
      {
        x <- Data2fd(argvals=D,y=x)
      }
      else
      {
        x <- Data2fd(argvals=D[[k]],y=x)
      }
    }
    
    if(!is.fd(x))
      stop("X must be a matrix, fd object or a list of matrices/fd objects")
    xfd[[k]] <- x
  }
  
  xfd
  
}
library(crayon);library(glmnet)
######### using slos data generator ############
# slos functions for generating data
slos.generate.test.dataNoIntcp <- function(nruns=1)
{
  n <- 150
  k <- 0
  m <- 1000
  intercept <- 0
  rangeval <- c(0,1)
  dat <- data.generatorflr(n,k,m,nruns,intercept,rangeval)
  dat
}
data.generatorflr <- function(n,k,m,nSimu,intercept,rangeval)
{
  nbasis=71+5-2
  data.basis <- create.bspline.basis(rangeval=rangeval,norder=5,nbasis=nbasis)
  
  N <- n + k + m
  
  G1 <- matrix(0,nbasis,1)
  for(j in 1:nbasis) G1[j] <- inner.prod(beta.func,data.basis,j)
  
  train <- list()
  valid <- list()
  test <- list()
  
  for(i in 1:nSimu)
  {
    cMat1 <- matrix(rnorm(N*nbasis),N,nbasis)
    yTru <- intercept + cMat1 %*% G1
    ySig <- sd(yTru)
    y <- yTru
    y[1:(n+k)] <- y[1:(n+k)]
    train[[i]] <- list(x=fd(coef=t(cMat1[1:n,]),basisobj=data.basis),y=y[1:n],intercept=intercept)
    if(k > 0) valid[[i]] <- list(x=fd(coef=t(cMat1[(n+1):(n+k),]),basisobj=data.basis),
                                 y=y[(n+1):(n+k)],intercept=intercept)
    if(m > 0) test[[i]] <- list(x=fd(coef=t(cMat1[(n+k+1):N,]),basisobj=data.basis),
                                y=y[(n+k+1):N],intercept=intercept)
    
  }
  
  dat <- list(train=train,valid=valid,test=test)
}


inner.prod <- function(f,basis,j)
{
  rng <- getbasisrange(basis)
  knots <- c(rng[1],basis$params,rng[2])
  nbasis <- basis$nbasis
  norder <- basis$nbasis - length(knots) + 2
  
  a <- rng[1]
  if(j-norder > 0) a <- knots[j-norder+1]
  
  b <- rng[2]
  if (j <= nbasis-norder) b <- knots[j+1]
  
  bfun <- function(t)
  {
    mat <- eval.basis(t,basis)
    z <- t(mat[,j])
  }
  
  y <- integrate(function(t) {f(t)*bfun(t)},a,b)
  y$value
}

# function to generate XFD for flr
data_slos_all = function(seed){
  set.seed(seed)
  nruns = 1
  dat = slos.generate.test.dataNoIntcp(nruns)
  i = 1
  datTrain = dat$train[[i]]
  datTest = dat$test[[i]]
  
  y.pre = datTrain$y
  ps = exp(y.pre)/(1+exp(y.pre)) # calculate the probabilities of each observation
  set.seed(seed)
  yTrain = rbinom(n=length(ps),size=1,prob = ps)
  print(paste('ratio of y=1 in Training dataset equals',sum(yTrain)/length(yTrain)))
  
  y.pre = datTest$y
  ps = exp(y.pre)/(1+exp(y.pre)) # calculate the probabilities of each observation
  set.seed(seed)
  yTest = rbinom(n=length(ps),size=1,prob = ps)
  print(paste('ratio of y=1 in Test dataset equals',sum(yTest)/length(yTest)))
  
  result = list()
  result$datTrain = datTrain
  result$yTrain = yTrain
  result$datTest = datTest
  result$yTest = yTest
  result
}

bcoef_init_glm=function(X,y, basis){
  nobs=length(y)
  basis_X=X[[2]]
  arg_X=c(basis_X$params,basis_X$rangeval[2])
  bmat_X=getbasismatrix(arg_X,basis_X)
  X_coef=X[[1]]
  X_curves=t(X_coef)%*%t(bmat_X)
  
  fit=cv.glmnet(X_curves,y,family = 'binomial',alpha = 0,intercept=F)
  beta=as.numeric(coef(fit))[-1]# beta(t)
  
  beta_obj=Data2fd(arg_X,beta,basis)
  beta_bcoef=beta_obj$coefs
  nbasis_beta=basis$nbasis
  arg_beta=c(basis$params,basis$rangeval[2]) # argvals of basis for slos/flr
  bmat_beta=getbasismatrix(arg_beta,basis)
  beta.b=t(beta_bcoef)%*%t(bmat_beta)
  beta_bcoef
}

#####FLR######
#flr.lqa() is the iterative N-R alg to compute basis coefficents estimates for this functional logistic regression with LASSO-type penalty
# flr.lqa() can output very small basis coefficents estimates, which then be forced to 0 in flr.alg()
# flr.alg() uses basis coefficents estimates from flr.lqa(), and force small estimates to 0, then
# truncate the positions of coefficient with estimate 0 in the design matrix U, which is used to calculate
# the final estimates of coefficients without penalty

#flr.alg() input basis coefficents estimates, and xfd is the fd object formatted by slos.preprocess()
#argvalst represents the data points in one observation
# cutoff is used to force small basis coefficents estimates to 0
# flr.alg()

flr.alg <- function(bcoef,xfd,y,lambda,gamma,beta.basis,cutoff,
                    max.iter,tol,Jmat,Ws=NULL,Vs=NULL,use.index=NULL,argvalst){
  K = length(xfd)# number of functional predictors
  Ls = rep(0,K)#number of basis functions for each functional predictor
  Ms = rep(0,K)#number of subintervals for each functional predictor; number of knots(including boundary knots)=M+1
  ds = rep(0,K)# degree of bspline used for each functional predictor; degree+1=order
  L2NNer = rep(0,K)
  for (k in 1:K){Ls[k] = beta.basis[[k]]$nbasis}#number of basis functions
  for (k in 1:K){ Ms[k] = length(beta.basis[[k]]$params) + 1}#The domain of t, T, is divided into M subintervals with M+1 equally spaced knots  
  for (k in 1:K){ds[k] = Ls[k] - Ms[k]}#Over each subinterval, each B-spline basis function Bj (t) is a polynomial of the degree d. Each B-spline basis function is nonzero over no more than d + 1 consecutive subintervals.
  for (k in 1:K){L2NNer[k] = sqrt(Ms[k]/diff(getbasisrange(xfd[[k]]$basis)))}#sqrt(M/T), where T is the domain
  P = c(0,cumsum(Ls))#c(0,number of basis functions)
  
  bmatrix = getbasismatrix(argvalst,beta.basis[[K]]) # obtain the estimates of bspline functions in bspline object
  # compute weight and roughness penalty matrices if they are NULL
  if(is.null(Vs)){
    Vs = list()
    for(k in 1:K){
      Vs[[k]] = eval.penalty(beta.basis[[k]],int2Lfd(2))
    }
  }
  
  
  # compute weight matrix Ws if they are NULL
  if(is.null(Ws)){
    Ws = list()# An array of Wjs, with dimension of (d+1,d+1,m), j=1:m
    for(k in 1:K){
      Ws[[k]] = slos.compute.weights(beta.basis[[k]]) # the core matrix of each Wj in the 3rd dimension. the (int B_u(t)B_v(t) dt) in each of m subintervals, u,v=t_j,:t_(j+d)
    }
  }
  
  
  # compute design matrix
  U = NULL
  VV = NULL
  
  if(!is.null(use.index)){ 
    y = y[use.index]
  }
  
  nobs = length(y) #number of observations
  
  for (k in 1:K){ # perform alg for each functional predictor 
    fdk = xfd[[k]] # get the fd object for kth functional predictor
    xcoef = fdk$coefs # coef matrix of x, an nbais-by-nobs matrix
    if(!is.null(use.index)){
      U = cbind(U,t(xcoef[,use.index])%*%Jmat[[k]])
    }else{
      Uk = t(xcoef)%*%Jmat[[k]] # xcoef*(int B_u(t)B_v(t) dt)=int X(t)B^T(t) dt; it is an nobs-by-nbais matrix
      U = cbind(U,Uk) # stack Uk matrix for K functional predictors
    }
    VV = gamma*Vs[[k]]
  }
  
  # input the initial estimate of basis coefficient for beta(t)
  bHat = bcoef
  bTilde = bHat
  # if sparse, perform SLoS, otherwise, bTilde is the solution to \beta
  if(lambda > 0){
    changeThres = tol
    lqa_result = flr.lqa(U,y,bHat,Ws,Ms,Ls,L2NNer,ds,
                         lambda,VV,changeThres,max.iter)
    bTilde = lqa_result$bHat
    lqa_it = lqa_result$it
    #plot beta(t) from bTilde from lqa
    # print(bTilde)
    beta_bTilde=t(bTilde)%*%t(bmatrix)
    #plot(argvalst,beta_bTilde,type='l', main = paste('lambda=', lambda,'gamma=', gamma, ', lqa output'))
    
    bTilde2 = bTilde# keep a copy of lqa bTilde
    bZero = (abs(bTilde) < cutoff)
    bTilde[bZero] = 0#force small bHat to zero
    
    if(sum(!bZero)==length(bTilde) || lqa_it>max.iter){# if no bcoef is 0 in bTilde or lqa_it>max.iter, continue with the lqa bcoef estimates, which has the penalty control instead of using estimates without penalty control
      bTilde = bTilde2
    }else{
      if(sum(!bZero)==0){#if all bcoef in bTilde are forced to 0 by cutoff, make a warning, and continue with values of bcoef in bTilde before cutoff
        cat(red("All coefficients forced to 0, adjust lambda"))
        bTilde = bTilde2
        bZero = rep(F,length(bTilde))
        bZero[bTilde==0] = T
      }
      
      #print(bTilde)
      #plot beta(t) from thresholded bTilde from lqa
      beta_bTilde = t(bTilde)%*%t(bmatrix)
     # plot(argvalst,beta_bTilde,type='l', main = paste('lambda=', lambda,'gamma=', gamma,', thresholded lqa'))
      bNonZero = !bZero
      U1 = as.matrix(U[,bNonZero])#update U by removing more zero coefficients; set as matrix incase when only 1 coefficent is left
      U1t = t(U1)
      U1b = U1%*%bTilde[bNonZero,drop=F]# equals int X(t)beta(t)dt
      ps = exp(U1b)/(1+exp(U1b))
      ps[U1b<=(-log(1e5-1))]=1e-5#force small probability to near 0 but not 0
      ps[U1b>=(log(1e5-1))]=1-1e-5#force probability close to 1 to near 1 but not 1
      
      c = as.numeric(ps)
      D = diag(c*(1-c),nobs,nobs)#(1-prob)*prob
      U1tDU1 = U1t%*%D%*%U1
      
      V1 = as.matrix(VV[bNonZero,bNonZero])
      
      deriv2=U1tDU1 + V1
      deriv1=-U1t%*%(y-c) + V1%*%bTilde[bNonZero,drop=F]
      bb = bTilde[bNonZero,drop=F]-solve(deriv2,deriv1)#this theta may have less coefficients than bHat
      bTilde = matrix(0,sum(Ls),1)
      bTilde[bNonZero,1] = matrix(bb,length(bb),1)
    }
  }
  #plot beta(t) using bTilde from ALG
  #print(bTilde)
  beta_bTilde=t(bTilde)%*%t(bmatrix)
  # plot(argvalst,beta_bTilde,type='l', main = paste('lambda=', lambda,'gamma=', gamma,', final estimate'))
  
  bNonZero = as.vector((bTilde != 0))
  U1 = as.matrix(U[,bNonZero])
  U1b = U1%*%bTilde[bNonZero,drop=F]# equals int X(t)beta(t)dt
  ps = exp(U1b)/(1+exp(U1b))
  ps[U1b<=(-log(1e5-1))]=1e-5 #force small probability to near 0
  ps[U1b>=(log(1e5-1))]=1-1e-5#force probability close to 1 to near 1
  
  ps = as.numeric(ps)
  result = list(beta=NULL,fitted.prob=ps)
  
  betaobj = list()
  for(k in 1:K){
    bfd = fd(coef=bTilde[(P[k]+1):(P[k+1])],basisobj=beta.basis[[k]])
    betaobj[[k]] = bfd
  }
  
  result$beta = betaobj
  result$beta.basis = beta.basis
  result
}


flr.lqa <- function(U,y,bHat,Ws,Ms,Ls,L2NNer,ds,lambda,V,changeThres,max.iter)
{
  Mmax = max(Ms)
  Lmax = max(Ls)
  K = length(Ms)
  P = c(0,cumsum(Ls))
  nobs = length(y)
  
  betaNormj = matrix(0,Mmax,K) # each column represents a functional predictor, and contains norm of beta function in the jth interval, j=1:m;
  bZeroMat = matrix(FALSE,1,sum(Ls)) # matrix with 1 row and sum(nbasis of each functional predictor); it indicates which basis coefficient shrink to 0
  betaNorm = rep(Inf,K)#to store new norm of entire beta(t) for K functional predictors
  it = 1 #set initial iteration
  while (it <= max.iter){
    betaNormOld = betaNorm
    for (k in 1:K){
      betaNorm[k] = slos.vec.norm(bHat[(P[k]+1):P[k+1]])#compute norm, sqrt(sum(bHat^2)), of bHat, ie. old basis coefficient estimates, for each functional predictor
    }
    change = max((betaNormOld-betaNorm)^2)
        if(it==max.iter){
print("divergence")    }
    
    if(change < changeThres) break

    lqaW = NULL
    
    for (k in 1:K){
      W = Ws[[k]]
      lqaWk = matrix(0,Ls[k],Ls[k])
      for(j in 1:Ms[k]){
        index = c(j:(j+ds[k]))
        bkj = bHat[P[k]+c(j:(j+ds[k]))]
        betaNormj[j,k] = sqrt(t(bkj) %*% W[,,j] %*% bkj)
        
        if(betaNormj[j,k] < changeThres){ 
          bZeroMat[P[k]+index] = TRUE
        }else{
          lqaWk[index,index] = lqaWk[index,index] + (1/betaNormj[j,k])*W[,,j]
        }
      }
      
      if(is.null(lqaW)){ 
        lqaW = lqaWk
      }
    }
    if(it>1e7){    
      browser()
    }
    bZeroVec = bZeroMat
    bNonZeroVec = !bZeroVec
    lqaW = lambda*lqaW/(2*L2NNer[k])
    Ub=as.matrix(U[,bNonZeroVec,drop=F])%*%bHat[bNonZeroVec,drop=F]# equals int X(t)beta(t)dt
    ps=exp(Ub)/(1+exp(Ub))
    ps[Ub<=(-log(1e5-1))]=1e-5 #force small probability to 0
    ps[Ub>=(log(1e5-1))]=1-1e-5#force probability close to 1 to 1
    c=as.numeric(ps)
    D = diag(c*(1-c),nobs,nobs)#(1-prob)*prob
    Ut = t(as.matrix(U[,bNonZeroVec,drop=F]))#only keep basis functions with nonzero coefficients
    UtDU = Ut%*%D%*%as.matrix(U[,bNonZeroVec,drop=F])
    
    Vp = as.matrix(V[bNonZeroVec,bNonZeroVec])
    
    deriv2 = UtDU + Vp+ lqaW[bNonZeroVec,bNonZeroVec,drop=F]
    deriv1 = -Ut%*%(y-c) + Vp%*%bHat[bNonZeroVec,drop=F] +lqaW[bNonZeroVec,bNonZeroVec,drop=F]%*%bHat[bNonZeroVec,drop=F]
    theta = bHat[bNonZeroVec,drop=F]-solve(deriv2,deriv1)#this theta may have less coefficients than bHat
    bHat = matrix(0,length(bNonZeroVec),1)
    bHat[bNonZeroVec,1] = matrix(theta,length(theta),1) #output bHat with nbasis coefficients
    
    it = it + 1
  }
  
  #print(it)
  result = list()
  result$bHat = bHat
  result$it = it
  result
}

flr <- function(X,y,K=1,D=NULL,lambda=0,gamma=0,beta.basis=NULL,cutoff=1e-4,
                max.iter=1000,tol=1e-12,domain=NULL,tuning=NULL){
  # D: the design points
  # X: predictor(s), could be a matrix (fd object) or list of matrix (fd objects)
  #    if matrix, then it is organized in the way that each column is an independent observation
  # y: a column vector, the response
  

    xfd = slos.preprocess.x(X,D)
  if(is.null(beta.basis)){
    beta.basis = list()
    for(k in 1:K){
      x = xfd[[k]]
      rng = getbasisrange(x$basis)
      beta.basis[[k]] = create.bspline.basis(rangeval=rng,nbasis=43)
    }
  }
  
  bcoef = bcoef_init_glm(xfd[[1]],y,beta.basis[[1]])
  
  argvalst=c(beta.basis[[1]]$params, beta.basis[[1]]$rangeval[2])
  Jmat = list()
  for(k in 1:K){
    Jmat[[k]] = inprod(xfd[[k]]$basis,beta.basis[[k]]) 
  }  
  
  if(length(gamma)>1 || length(lambda)>1){

    tuned = flr.tune(bcoef,xfd,y,lambda,gamma,beta.basis,cutoff,
                     max.iter,tol,Jmat,tuning,Ws=NULL,Vs=NULL,argvalst)
    result = flr.alg(bcoef,xfd,y,tuned$lambda,tuned$gamma,beta.basis,cutoff,
                     max.iter,tol,Jmat,Ws=NULL,Vs=NULL,use.index=NULL,argvalst )
    result$lambda = tuned$lambda
    result$gamma = tuned$gamma
    result$score = tuned$score
    result
  }else{
    flr.alg(bcoef,xfd,y,lambda,gamma,beta.basis,cutoff,
            max.iter,tol,Jmat,Ws=NULL,Vs=NULL,use.index=NULL,argvalst)
  }
}



flr.tune <- function(bcoef,xfd,y,lambdas,gammas,beta.basis,cutoff,
                     max.iter,tol,Jmat,tuning= 'CV',Ws=NULL,Vs=NULL,argvalst){
  K = length(xfd) #number of predictor functions
  # compute weight and roughness penalty matrices if they are NULL
  if(is.null(Vs)){
    Vs = list()
    for(k in 1:K){
      Vs[[k]] = eval.penalty(beta.basis[[k]],int2Lfd(2))
    }
  }
  
  # compute weight and roughness penalty matrices if they are NULL
  if(is.null(Ws)){
    Ws = list()
    for(k in 1:K){
      Ws[[k]] = slos.compute.weights(beta.basis[[k]])
    }
  }#Ws is the int B(t)B(t) dt matrix for M breaks, (M+1) breaks in total, B(t) stands for Bspline
  
  dm = dim(xfd[[1]]$coef) # dimesion of the Bspline coefficient matrix of X(t)
  nobs = dm[2]#number of observations
  
  llh.score = matrix(0,length(lambdas),length(gammas))#the storing matrix for the loglikelihood resulted from each lambda and gama
  
  Kfold = 10 #set 10-fold cv
  idx = sample(1:nobs,nobs) # shuffle data
  
  s = ceiling(nobs/Kfold) #number of sets of training data and testing data 
  
  if(tuning!='CV'){
    
    if(tuning=='AIC'){
      for(i in 1:length(lambdas)){
        for(j in 1:length(gammas)){
          fit = flr.alg(bcoef,xfd,y,lambdas[i],gammas[j],beta.basis,cutoff,
                        max.iter,tol,Jmat,Ws,Vs,use.index=NULL,argvalst)
          phat = predict.flr(fit,xfd,use.index=NULL)
          probi = phat^y*(1-phat)^(1-y)#probablity of each observation in the test dataset
          llh = sum(log(probi))#loglikelihood of the test dataset
          bcoef_fit = coef(fit$beta[[1]])
          df = sum(bcoef_fit!=0)
          llh.score[i,j] = -2*llh+2*df
        }
      }
      
    }else if(tuning=='BIC'){
      for(i in 1:length(lambdas)){
        for(j in 1:length(gammas)){
          
          fit = flr.alg(bcoef,xfd,y,lambdas[i],gammas[j],beta.basis,cutoff,
                        max.iter,tol,Jmat,Ws,Vs,use.index=NULL,argvalst)
          phat = predict.flr(fit,xfd,use.index=NULL)
          probi = phat^y*(1-phat)^(1-y)#probablity of each observation in the test dataset
          llh = sum(log(probi))#loglikelihood of the test dataset
          bcoef_fit = coef(fit$beta[[1]])
          df = sum(bcoef_fit!=0)
          llh.score[i,j] = -2*llh+log(nobs)*df
        }
      }
    }else if(tuning=='RIC'){
      
    }else{
      cat(red("Tuning not available"))
    }
    
    h = which(llh.score==min(llh.score),arr.ind=T)#BIC choose the minimum score
    list(score=llh.score,lambda=lambdas[h[1,1]],gamma=gammas[h[1,2]],min.score=min(llh.score))
  }else{
    for(i in 1:length(lambdas))
    {
      for(j in 1:length(gammas))
      {
        llh.cv = matrix(0,1,Kfold) 
        for(k in 1:Kfold)
        {
          test.index = idx[(s*(k-1)+1):min(s*k,nobs)]
          train.index = idx[-((s*(k-1)+1):min(s*k,nobs))]
          fit = flr.alg(bcoef,xfd,y,lambdas[i],gammas[j],beta.basis,cutoff,
                        max.iter,tol,Jmat,Ws,Vs,use.index=train.index,argvalst)
          
          phat = predict.flr(fit,xfd,test.index)
          
          probi=phat^y[test.index]*(1-phat)^(1-y[test.index])#probablity of each observation in the test dataset
          llh = sum(log(probi))#/length(train.index)#loglikelihood of the test dataset
          llh.cv[k] = llh
        }
        llh.i = sum(llh.cv)#loglikelihood of all test datasets given a lambda
        
        llh.score[i,j] <- llh.i
      }
    }
    
    h = which(llh.score==max(llh.score),arr.ind=T)
    list(score=llh.score,lambda=lambdas[h[1,1]],gamma=gammas[h[1,2]],max.score=max(llh.score))#CV choose the max likelihood
  }
}

predict.flr <- function(slosobj,newX,use.index=NULL,domain=NULL)
{
  xfd <- slos.preprocess.x(newX,domain)
  K <- length(xfd)
  
  for(k in 1:K)
  {
    x <- xfd[[k]]
    b <- slosobj$beta[[k]]
    G <- inprod(x$basis,b$basis)
    
    if(!is.null(use.index)){
      y = t(x$coef[,use.index]) %*% G %*% b$coef #int X(t)beta(t)dt
    }else{
      y =  t(x$coef) %*% G %*% b$coef#int X(t)beta(t)dt
    } 
    p=exp(y)/(1+exp(y))#probability
    p[y<=(-log(1e5-1))]=1e-5#force small probability to near 0
    p[y>=(log(1e5-1))]=1-1e-5#force probability close to 1 to near 1
  }
  p
}


library(fda)
library(pracma)
library(mvtnorm)
library(MASS)
library(matrixcalc);library(crayon);library(glmnet)


########beta(t) with two nonnull subregions #####
FLR_sim5=function(dat, y, data_test, y_test){
  X = dat$x
  train = flr(X,y,K=1,D=NULL,lambda,gamma,beta.basis=NULL,cutoff=1e-4,
              max.iter=1000,tol=1e-12,domain=NULL,tuning)

  # estimate beta function
  betaFD = train$beta[[1]]
  argvals = seq(betaFD$basis$rangeval[1], betaFD$basis$rangeval[2], length.out = 100)
  betaHat_mat = getbasismatrix(argvals, betaFD$basis)
  betaHat = t(betaFD$coefs) %*% t(betaHat_mat)

  # Calculation standard error
  se_beta = sqrt(diag(var(betaHat)))  

 
  alpha = 0.05  # 95% 置信区间
  ci_upper = betaHat + qnorm(1 - alpha / 2) * se_beta
  ci_lower = betaHat - qnorm(1 - alpha / 2) * se_beta


  ci_upper[is.na(ci_upper) | is.infinite(ci_upper)] <- max(betaHat, na.rm = TRUE) + 1
  ci_lower[is.na(ci_lower) | is.infinite(ci_lower)] <- min(betaHat, na.rm = TRUE) - 1

  ylim_range <- range(c(ci_lower, ci_upper, betaHat), na.rm = TRUE)
  buffer <- diff(ylim_range) * 0.1  # 添加10%的缓冲区
  ylim_range <- c(ylim_range[1] - buffer, ylim_range[2] + buffer)

  # plot beta function
    plot(beta.func, xlab='t', ylab=expression(beta(t)), ylim=ylim_range)
   lines(argvals, betaHat, col='red')

  # Add confidence band
  lines(argvals, ci_upper, col='green', lty=2)  # Upper confidence interval
  lines(argvals, ci_lower, col='green', lty=2) 
  # predict
  phat = predict.flr(train, data_test$x)
  y_predicted = as.numeric(phat >= 0.5)
  n_test = length(y_test)

 betaFD=train$beta[[1]]
  betaHat_mat=getbasismatrix(beta_truet,betaFD$basis)
  betaHat=t(betaFD$coefs)%*%t(betaHat_mat)
  
  arg_X=beta_truet
  if(l0!=1){
    arg_Xl0_ind=arg_X<l01 | (arg_X>l02 & arg_X<l03) | arg_X>l04
    arg_Xl0=arg_X[arg_Xl0_ind]
    betaHatl0=betaHat[arg_Xl0_ind]
    arg_Xl1=arg_X[!arg_Xl0_ind]
    betaHatl1=betaHat[!arg_Xl0_ind]
    ise0=sum((betaHatl0-beta.func(arg_Xl0))^2)/length(arg_X)/l0#ISE_0: integrated square error
    ise1=sum((betaHatl1-beta.func(arg_Xl1))^2)/length(arg_X)/l1#ISE_1: integrated square error
  }else{
    ise0=sum((betaHat-beta.func(arg_X))^2)/length(arg_X)/l0#ISE_0: integrated square error
  }
  pmse=sum((data_test$y-phat)^2)/n_test#PMSE: prediction mean squared errors
  
  #misclassification rate
  misc = mean(y_predicted!=y_test)
  #sensitivity, ALSO called true positive rate
  sum_truePos = sum(y_test) # number of true Positives
  truePos_ind = order(y_test,decreasing = T)[1:sum_truePos]# indices of true positives
  sum_Pos_pred = sum(y_predicted)# number of detected Positives
  Pos_pred_ind = order(y_predicted,decreasing = T)[1:sum_Pos_pred]# indices of detected positives
  sens = sum(Pos_pred_ind %in% truePos_ind)/sum_Pos_pred#sensitivity: number of true positives detected/number of positives detected 
  #specificity
  sum_trueNeg=n_test-sum_truePos # number of true negatives
  trueNeg_ind= order(y_test,decreasing = F)[1:sum_trueNeg]# indices of true positives
  sum_Neg_pred=n_test-sum_Pos_pred# number of detected negatives
  Neg_pred_ind= order(y_predicted,decreasing = F)[1:sum_Neg_pred]# indices of detected negatives
  spec = sum(Neg_pred_ind %in% trueNeg_ind)/sum_Neg_pred#specificity
  # false discorvery rate
  FDR = (sum_Pos_pred-sum(Pos_pred_ind %in% truePos_ind))/sum_Pos_pred
  accu=1-misc
  FNR=1-sens
  prec=1-FDR# precision
  if(l0!=1){
    rates=data.frame(misc, accu, sens, spec, FNR, FDR, prec,ise0,ise1,pmse )
  }else{
    rates=data.frame(misc, accu, sens, spec, FNR, FDR, prec,ise0,pmse )
  }
  rates
}

#simulation 5
#beta.func=function(t){
#  t=t+0.5
#  c=-100
#  y=(1-t)*sin(4*pi*(t+0.2))*c
#  y[t<0.55]=0
#  y[t>0.8]=0
#  y[t>1.2]=-sin(4*pi*(t[t>1.2]-0.2))*c/4
#  y[t>1.45]=0
#  y
#}



beta.func=function(t){
  t=t+0.5
  c=-100
  y=(1-t)*sin(4*pi*(t+0.2))*c
  y[t<0.55]=0
  y[t>0.8]=0
  y[t>1.2]=-cos(4*pi*(t[t>1.2]-0.2))*c/4
  y[t>1.45]=0
  y
}

#plot(seq(0,1,0.01),beta.func(seq(0,1,0.01)), type='l')
l00=0;l01=0.05;l02=0.3;l03=0.7;l04=0.95;l05=1
l0=l01-l00+l03-l02+l05-l04
l1=1-l0
ntests=100
set.seed(2020)
seeds=sample(1:1e5,ntests,replace = T)
beta_truet=seq(0,1,length.out = 200)
beta_true=beta.func(beta_truet)
tuning='BIC';gamma=c(1e-7,1e-8,1e-9,5e-10)*1500
lambda=c(0.006,0.007,8e-3,9e-3,9.5e-3,1e-2)*1700

ratesFLR=NULL
  i=24
  print(i)
  seed = seeds[i]
  datAll = data_slos_all(seed)
  dat = datAll$datTrain
  y = datAll$yTrain
  data_test = datAll$datTest
  y_test = datAll$yTest
  
K=1
X = dat$x
xfd = slos.preprocess.x(X,D)

    beta.basis = list()
    for(k in 1:K){
      x = xfd[[k]]
      rng = getbasisrange(x$basis)
      beta.basis[[k]] = create.bspline.basis(rangeval=rng,nbasis=43)
}


  ratesFLR = rbind(ratesFLR, FLR_sim5(dat, y, data_test, y_test))


mediansFLR=apply(ratesFLR, 2, median)
meanFLR=apply(ratesFLR, 2, mean)
sdFLR=apply(ratesFLR, 2, sd)

mediansFLR

